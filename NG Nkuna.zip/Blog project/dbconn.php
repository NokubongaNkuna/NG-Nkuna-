
<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "myblogass";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error); // connecting to database
 mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // not be strict
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }

 function dispdata($conn){

	$result = $conn -> query("SELECT * FROM blog_comments");
	
		return $result;
	  
 }



   

 if (isset($_POST['Delete'])) {
	$conn = mysqli_connect('localhost', 'root', '','myblogass'); 
    // If you receive the Delete post data, delete it from your table
    $delete = 'DELETE FROM blog_comments WHERE id = ?';
    $stmt = $conn->prepare($delete);
    $stmt->bind_param("i", $_POST['Delete']);
    $stmt->execute();
	header("Location: ../blogass/blog.php");
}

?>