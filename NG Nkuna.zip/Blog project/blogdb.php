<?php
// database connection code
if(isset($_POST['username'])) // checking if the fill has any value 
{
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$con = mysqli_connect('localhost', 'root', '','myblogass'); // connection to database

// get the post records

$names = $_POST['username'];
$email = $_POST['useremail'];
$comment  = $_POST['usercomment'];


// database insert SQL code
$sql = "INSERT INTO `blog_comments` ( `names`, `email`, `comment`) VALUES ( '$names', '$email', '$comment')";

// insert in database 
$rs = mysqli_query($con, $sql);
if($rs)
{
	echo "comment  Records Inserted";
	header("Location: ../blogass/blog.php");
}
}
else
{
	echo "Are you a genuine visitor?";
	
}
?>
