<?php
require_once('../myblog/dbconn.php');
$conn = OpenCon();
$blogss = dispdata($conn);
$blogss->fetch_assoc();
echo "<table border='1'>
<tr>
<th>Tittle</th>
<th>Content</th>
</tr>";

foreach($blogss as $row)
{
echo "<tr>";
echo "<td>" . $row['bltitle'] . "</td>";
echo "<td>" . $row['blcontent'] . "</td>";
echo "</tr>";
}
echo "</table>";
CloseCon($conn);

?>