<?php
require_once('../blogass/dbconn.php');
$conn = OpenCon();
$comments = dispdata($conn);
$comments->fetch_assoc();
echo '<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://cdn.tailwindcss.com"></script>


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap.min.css" >
    <link rel="stylesheet" href="./css/Blog.css" >

    <title>Hello, world!</title>

  </head>
  <body style="background-color:lightblue";>
    <style>
body {
background-image: url(".\Boostrap\Blog Ass\pics\smarter.jpeg");
}
</style>

    <div class="container">
  <div class="jumbotron">
    <h1> <p class="text-danger"><u>The Fifth Industrial Revolution(5IR)</u> </p></h1>
    <p class="text-success"><i>The combination of humans and machines in the workplace.</i></p>
  </div>
 </div>
 <div class="topnav">
   <ul>
   <li><a class="active" href="./Boostrap/Blog%20Ass/Blog.html">Home</a></li>
   <li><a href="https://newsonair.com/2022/02/01/fifth-industrial-revolution-5ir-preparedness/">News</a></li>

   <li><a href="https://www.africa.com/purpose-centricity-in-the-fifth-industrial-revolution/">About</a></li>
 </ul>
 <form role="search" id="form">
  <input type="search" id="query" name="q"
   placeholder="Search..."
   aria-label="Search through site content">
  <button>
    <svg viewBox="0 0 1024 1024"><path class="path1" d="M848.471 928l-263.059-263.059c-48.941 36.706-110.118 55.059-177.412 55.059-171.294 0-312-140.706-312-312s140.706-312 312-312c171.294 0 312 140.706 312 312 0 67.294-24.471 128.471-55.059 177.412l263.059 263.059-79.529 79.529zM189.623 408.078c0 121.364 97.091 218.455 218.455 218.455s218.455-97.091 218.455-218.455c0-121.364-103.159-218.455-218.455-218.455-121.364 0-218.455 97.091-218.455 218.455z"></path></svg>
  </button>
</form>
</div>
<br>
<div class="row">
   <div class="col" >
     <div class="container">

     <div class="card img-fluid" style="width:90%">
       <img class="card-img-top" src="./Images/smarter.jpeg " alt="Card image" style="width:100%">
       <br>
       <img class="card-img-top" src="./Images/5ir.png " alt="Card image" style="width:100%">
       <br>
       <img class="card-img-top" src="./Images/the_5ir.jpeg " alt="Card image" style="width:100%">

       <div class="card-img-overlay">
         <h4 class="card-title" style="color:blue ;text-align:center">The 5th Artifictial Intelligent</h4>

       </div>
     </div>
     </div>
   </div>

   <div class="col">
     <p><img src="./Images/Industrial-revolutions-5.jpg" style="width:70%"></p>
    <p>The 5IR is a concept that has been designed  to  harmonize the working space and efficiency of humans and
      machines in a consistent manner.Enabled by a variety of emerging applications  and supporting technologies,
       the 5IR is expected to increase manufacturing production and customer satisfaction. In this work,
       we  presented  our thoughts on  supporting  technologies and  potential applications of  the 5IR.</p>
       <p>The 5IR focuses  on stakeholder  value rather  than shareholder  value, reinforcing the industrys role and
         contribution to society. Below are the key drivers of 5IR
        <li> Human-centric:  Human  ingenuity  and
          craftsmanship  are  combined  with  the  speed,  efficiency,  and consistency of robots in 5IR. Thus it promotes human empowerment,
           talent, and diversity.
         </li>
          <li>Sustainability: Additive manufacturing, often known as 3D printing, is one of the most notable elements of 5IR, and
            it is used to make manufacturing items more sustainable. In 5IR, additive manufacturing aimed to improve customer happiness by
             incorporating benefits into goods and services.
             </li>
            <li>Resilient: The  term  "resilience"  refers  to  the  necessity  to  improve  industrial productions  robustness.
             High resilience can be attained when humans and robots operate together.
           </li>
            <li>Reduced cost and environmental control: Climate, humidity, temperature, and energy usage are all monitored in  real-time  and
               predicted  using  smart,  networked  sensors  and  specialized  algorithms.  This  is  especially beneficial in farms that are
                highly dependent on the weather. Knowing what to expect and where to act might help to avoid costly mistakes and boost the output.
              </li>
             </p>
  </div>


</div>
<br>

';
echo'<h3 align="center">Comments Section </h3>
<form action="dbconn.php" method = "post">';
foreach($comments as $comment){
echo'<div align="center">
<div align="left" class="bg-white w-full sm:max-w-7xl md:w-1/3 h-auto shadow px-3 py-2 flex flex-col space-y-2">
    
<div class="flex items-center space-x-2">
   <div class="flex flex-shrink-0 self-start cursor-pointer">
     <img src="https://images.unsplash.com/photo-1551122089-4e3e72477432?ixid=MXwxMjA3fDB8MHxzZWFyY2h8M3x8cnVieXxlbnwwfHwwfA%3D%3D&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=500&amp;q=60" alt="" class="h-8 w-8 object-fill rounded-full">
   </div>

   <div class="flex items-center justify-center space-x-2">
     <div class="block">
       <div class="bg-gray-100 w-auto rounded-xl px-2 pb-2">
         <div class="font-medium">
           <a  href="#" class="hover:underline text-sm">
             <small >'. $comment['names'].'</small>
           </a>
         </div>
         <div class="text-xs">
         '. $comment['comment'].'
         </div>
       </div>
       <div class="flex justify-start items-center text-xs w-full">
         <div class="font-semibold text-gray-700 px-2 flex items-center justify-center space-x-1">
          <small class="self-center">.</small>
           <a href="#" class="hover:underline">
             <small>'. $comment['created_at'].'</small>
           </a>
         </div>
         <div class="font-semibold text-gray-700 px-2 flex items-center justify-center space-x-1">
          <small class="self-center">.</small>
           <a href="#" class="hover:underline">
           <button align="right" type="submit" name="Delete" value="'.$comment['id'].'">Delete comment</button>
           </a>
         </div>
       </div>
       
     </div>
   </div>

   <div class="self-stretch flex justify-center items-center transform transition-opacity duration-200 opacity-0 translate -translate-y-2 hover:opacity-100">
     <a href="#" class="">
       <div class="text-xs cursor-pointer flex h-6 w-6 transform transition-colors duration-200 hover:bg-gray-100 rounded-full items-center justify-center">
         <svg class="w-4 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"></path></svg>
       </div>

     </a>
   </div>

 </div>

 </div> 
</div>';




}


echo '</form>
</div>


  <div class="container">
    <form action="blogdb.php" method="post">
    <br>

    <p><strong>We would like to know how familia are you and what can you say regarding the 5IR.</strong></p>
      
       <br>
      <label>Name and Surnam</label>
       <input name="username" type="text" class="form-control" placeholder="Nokubonga Nkuna">
        <br>

      <label>Email</label>
      <input name="useremail" type="email" class="form-control" placeholder="Nkuna@.com">
      <br>
    <h2>Comment</h2>
    <textarea name="usercomment" class="form-control" rows="5" id="ArtText"></textarea>
    <br>
      
    <br>
    <button type="submit"  class="btn btn-primary">Submit</button>

    </form>
  </div>
  <br>
  <div class="container">
    <h1>The Fifth Industrial Revolution </h1>
    <p>One move can make a change</p>
    <blockquote class="blockquote">
      <p>Nokubonga Nkuna.</p>
      <footer class="blockquote-footer">Powered by TUT</footer>
    </blockquote>
  </div>
    <!-- Op,tional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./js/jquery.js" ></script>
    <script src="./js/popper.min.js" ></script>
    <script src="./js/bootstrap.min.js" ></script>
  </body>
</html>
';
CloseCon($conn);

?>;


