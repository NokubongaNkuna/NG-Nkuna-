<?php
require_once('../myblog/dbconn.php');
$conn = OpenCon();
$blogss = dispdata($conn);

CloseCon($conn);

?>